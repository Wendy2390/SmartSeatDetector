package com.example.smart_seat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartSeatApplicationTests {

	@Test
	void contextLoads() {
	}

}
