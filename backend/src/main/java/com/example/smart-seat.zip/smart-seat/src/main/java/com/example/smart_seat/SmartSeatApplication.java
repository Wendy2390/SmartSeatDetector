package com.example.smart_seat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartSeatApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartSeatApplication.class, args);
	}

}
